/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 images/bg images/bg.png 
 * Time-stamp: Saturday 11/16/2019, 20:41:42
 * 
 * Image Information
 * -----------------
 * images/bg.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BG_H
#define BG_H

extern const unsigned short bg[38400];
#define BG_SIZE 76800
#define BG_LENGTH 38400
#define BG_WIDTH 240
#define BG_HEIGHT 160

#endif

