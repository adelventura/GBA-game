/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 images/splash_screen images/splash_screen.png 
 * Time-stamp: Sunday 11/17/2019, 19:01:10
 * 
 * Image Information
 * -----------------
 * images/splash_screen.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SPLASH_SCREEN_H
#define SPLASH_SCREEN_H

extern const unsigned short splash_screen[38400];
#define SPLASH_SCREEN_SIZE 76800
#define SPLASH_SCREEN_LENGTH 38400
#define SPLASH_SCREEN_WIDTH 240
#define SPLASH_SCREEN_HEIGHT 160

#endif

