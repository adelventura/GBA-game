/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=10x10 images/shark images/shark.png 
 * Time-stamp: Sunday 11/17/2019, 19:05:09
 * 
 * Image Information
 * -----------------
 * images/shark.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SHARK_H
#define SHARK_H

extern const unsigned short shark[100];
#define SHARK_SIZE 200
#define SHARK_LENGTH 100
#define SHARK_WIDTH 10
#define SHARK_HEIGHT 10

#endif

