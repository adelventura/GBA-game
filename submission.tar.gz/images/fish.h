/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=50x37 images/fish images/fish.png 
 * Time-stamp: Saturday 11/16/2019, 15:50:38
 * 
 * Image Information
 * -----------------
 * images/fish.png 50@37
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FISH_H
#define FISH_H

extern const unsigned short fish[1850];
#define FISH_SIZE 3700
#define FISH_LENGTH 1850
#define FISH_WIDTH 50
#define FISH_HEIGHT 37

#endif

